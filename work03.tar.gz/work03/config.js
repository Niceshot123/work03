module.exports = {
    token: '',
    prefix: '!',
    ownerId: ["682902737595531277", "815430958621786122", "933756317846347787"],
    clientId: "",
    guildId: ""
}
